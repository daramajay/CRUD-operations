﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobftpFileProperties
    {
        public long Id { get; set; }
        public DateTime Date { get; set; }
        public string Act { get; set; }
        public string Remark { get; set; }
        public string Customerno { get; set; }
        public string Ticketno { get; set; }
        public string Department { get; set; }
        public string Budget { get; set; }
        public string Customeref { get; set; }
        public string Workorder { get; set; }
        public string Dcompany { get; set; }
        public string Daddress { get; set; }
        public string Dflr { get; set; }
        public string Dcity { get; set; }
        public string Dstate { get; set; }
        public string Dzipcode { get; set; }
        public string Dcontact { get; set; }
        public string Dphone { get; set; }
        public int? Quantity { get; set; }
        public double? Weight { get; set; }
        public string Description { get; set; }
        public string Ptype { get; set; }
        public int? Pquantity { get; set; }
        public string Pdescription { get; set; }
        public int Ok { get; set; }
        public DateTime? Okdate { get; set; }
        public string Signature { get; set; }
        public DateTime? Jdate { get; set; }
        public string Pcompany { get; set; }
        public string Paddress { get; set; }
        public string Pflr { get; set; }
        public string Pcity { get; set; }
        public string Pstate { get; set; }
        public string Pzipcode { get; set; }
        public string Pcontact { get; set; }
        public string Pphone { get; set; }
        public string Actcode { get; set; }
        public string Latlng { get; set; }
        public string Courieridno { get; set; }
        public string Note { get; set; }
        public string Pact { get; set; }
        public string Pactcode { get; set; }
        public string Platlng { get; set; }
        public string Okfile { get; set; }
        public string Pono { get; set; }
        public string Cono { get; set; }
    }
}
