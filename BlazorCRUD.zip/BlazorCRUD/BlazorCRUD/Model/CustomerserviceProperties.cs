﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomerserviceProperties
    {
        public string Customerno { get; set; } // Need to get from Customermaintenance table
        public string Servicetype { get; set; }
        public bool Usemask { get; set; }
        public long Rowguid { get; set; }
        public string Mask { get; set; }
    }
}
