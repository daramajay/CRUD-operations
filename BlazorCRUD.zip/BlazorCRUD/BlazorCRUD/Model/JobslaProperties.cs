﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobslaProperties
    {
        public int Id { get; set; }
        public string Customerno { get; set; } //Unique
        public string Servicetype { get; set; }
        public int Day { get; set; }
        public int Hour { get; set; }
        public int Minute { get; set; }
    }
}
