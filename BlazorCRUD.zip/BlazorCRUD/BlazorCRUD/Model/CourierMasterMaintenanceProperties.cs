﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class CourierMasterMaintenanceProperties
    {
        public string Courieridno { get; set; } //Unique
        public string Couriertype { get; set; }
        public string Compno { get; set; }
        public string Location { get; set; }
        public string Paymentsource { get; set; }
        public DateTime? Bdate { get; set; }
        public DateTime? Hdate { get; set; }
        public DateTime? Tdate { get; set; }
        public string Employeeidno { get; set; }
        public string Hphone { get; set; }
        public string Phone { get; set; }
        public string Ssno { get; set; }
        public string Department { get; set; }
        public string Maritalstatus { get; set; }
        public short? Nbofdependant { get; set; }
        public string Nyresidentcode { get; set; }
        public string Paymenttype { get; set; }
        public string Email { get; set; }
        public string Radiobeeper { get; set; }
        public string Couriername { get; set; }
        public string Shortname { get; set; }
        public string Name { get; set; }
        public decimal? Paymentrate { get; set; }
        public string Address { get; set; }
        public string Vendortype { get; set; }
        public string Glaccount { get; set; }
        public double Incdec { get; set; }
        public string Pflag { get; set; }
        public bool? Active { get; set; }
        public string Masterid { get; set; }
        public long Rowguid { get; set; }
        public string Pwd { get; set; }
        public bool Gocanvas { get; set; }
        public string Emailgocanvas { get; set; }
        public string Pwdgocanvas { get; set; }
        public bool? Newflag { get; set; }
        public string Gcmid { get; set; }
        public string Note { get; set; }
        public bool Outnwk { get; set; }
        public string Picture { get; set; }
        public string Dispzone { get; set; }
        public bool Wp { get; set; }
        public bool Sc { get; set; }
        public string Vehicule { get; set; }
        public string Pictureid { get; set; }
        public DateTime? Clocktime { get; set; }
        public string Clockstatus { get; set; }
        public bool? Monday { get; set; }
        public bool? Tuesday { get; set; }
        public bool? Wednesday { get; set; }
        public bool? Thursday { get; set; }
        public bool? Friday { get; set; }
        public bool Saturday { get; set; }
        public bool Sunday { get; set; }
        public string Mondaystime { get; set; }
        public string Mondayetime { get; set; }
        public string Tuesdaystime { get; set; }
        public string Tuesdayetime { get; set; }
        public string Wednesdaystime { get; set; }
        public string Wednesdayetime { get; set; }
        public string Thursdaystime { get; set; }
        public string Thursdayetime { get; set; }
        public string Fridaystime { get; set; }
        public string Fridayetime { get; set; }
        public string Saturdaystime { get; set; }
        public string Saturdayetime { get; set; }
        public string Sundaystime { get; set; }
        public string Sundayetime { get; set; }
        public DateTime? Gpsdate { get; set; }
        public float? Latitude { get; set; }
        public float? Longitude { get; set; }
        public string Batterylevel { get; set; }
        public bool Facereq { get; set; }
        public bool Geotag { get; set; }
        public string Speed { get; set; }
        public decimal Hrate { get; set; }
    }
}
