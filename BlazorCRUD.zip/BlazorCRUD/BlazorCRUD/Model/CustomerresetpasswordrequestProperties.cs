﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomerresetpasswordrequestProperties
    {
        public long Id { get; set; }
        public int? UserId { get; set; } //get from the Cemployee table
        public DateTime? ResetRequestDateTime { get; set; }
    }
}
