﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobcaseProperties
    {
        public string Customerno { get; set; }
        public string Ticketno { get; set; }
        public DateTime Date { get; set; }
        public string Time { get; set; }
        public string Operator { get; set; }
        public string Note { get; set; }
        public string Status { get; set; }
        public long Id { get; set; }
    }
}
