﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class AppointmentProperties
    {

        public int Id { get; set; }
        public string Username { get; set; }
        public string Customerno { get; set; }
        public int? Status { get; set; }
        public string Subject { get; set; }
        public string Description { get; set; }
        public int? Label { get; set; }
        public DateTime? Starttime { get; set; }
        public DateTime? Endtime { get; set; }
        public string Location { get; set; }
        public byte? Allday { get; set; }
        public int? Eventtype { get; set; }
        public string Recurrenceinfo { get; set; }
        public string Reminderinfo { get; set; }
        public string Contactinfo { get; set; }
        public string Department { get; set; }
    }
}
