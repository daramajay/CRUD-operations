﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JoblogProperties
    {
        public string Customerno { get; set; }
        public string Ticketno { get; set; }
        public string Operator { get; set; }
        public DateTime Date { get; set; }
        public string Time { get; set; }
        public string Description { get; set; }
        public long Rowguid { get; set; }
    }
}
