﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class CinstructionProperties
    {
        public int Id { get; set; }
        public int Empid { get; set; }
        public string Instruction { get; set; }
    }
}
