﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomerdepartmentmaintenanceProperties
    {
        public string Customerno { get; set; } // get from the Customermaintenance table
        public string Department { get; set; }
        public string Zipcode { get; set; }
        public string Flr { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Extension { get; set; }
        public string Budget { get; set; }
        public string Workorder { get; set; }
        public string Customref { get; set; }
        public string Departmentname { get; set; }
        public string Contact { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Ustate { get; set; }
        public string Name { get; set; }
        public bool Dpa { get; set; }
        public bool? Active { get; set; }
        public long Rowguid { get; set; }
        public string Instruction { get; set; }
        public bool Inva { get; set; }
    }
}
