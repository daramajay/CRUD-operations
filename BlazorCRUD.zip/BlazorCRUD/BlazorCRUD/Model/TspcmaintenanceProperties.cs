﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class TspcmaintenanceProperties
    {
        public string Customerno { get; set; }
        public string Courieridno { get; set; }
        public string Couriername { get; set; }
        public string Servicetype { get; set; }
        public decimal? Hrate { get; set; }
        public double? Otf { get; set; }
        public long Rowguid { get; set; }
    }
}
