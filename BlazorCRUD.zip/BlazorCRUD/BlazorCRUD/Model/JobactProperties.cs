﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobactProperties
    {
        public string Customerno { get; set; }
        public string Ticketno { get; set; }
        public string Courieridno { get; set; }
        public string Act { get; set; }
        public DateTime Date { get; set; }
        public string Time { get; set; }
        public string Remark { get; set; }
        public long Rowguid { get; set; }
        public string Signature { get; set; }
        public string Picture { get; set; }
        public string Dlocation { get; set; }
        public string Latlng { get; set; }
        public string Actcode { get; set; }
        public string Bycourier { get; set; }
        public string Phonetype { get; set; }
    }
}
