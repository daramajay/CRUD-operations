﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class TagmaintenanceProperties
    {
        public long Id { get; set; }
        public string Name { get; set; } //Unique
        public string Description { get; set; }
    }
}
