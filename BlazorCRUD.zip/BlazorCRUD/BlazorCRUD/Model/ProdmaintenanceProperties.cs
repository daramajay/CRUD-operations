﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class ProdmaintenanceProperties
    {
        public string Customerno { get; set; }
        public string Servicetype { get; set; }
        public decimal? Dispatch { get; set; }
        public decimal? Handling { get; set; }
        public decimal? Process { get; set; }
        public decimal? Storage { get; set; }
        public decimal? Change { get; set; }
        public long Rowguid { get; set; }
    }
}
