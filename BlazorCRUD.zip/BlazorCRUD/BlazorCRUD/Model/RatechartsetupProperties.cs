﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class RatechartsetupProperties
    {
        public string Billingtype { get; set; }
        public string Servicetype { get; set; }
        public string Zonecode { get; set; }
        public string Customerno { get; set; } //Get from Customermaintenance table
        public decimal Sbbase { get; set; }
        public decimal Cbbase { get; set; }
        public decimal? Sbrate { get; set; }
        public decimal? Cbrate { get; set; }
        public decimal? Smbilling { get; set; }
        public decimal? Cmbilling { get; set; }
        public decimal Sbpark { get; set; }
        public decimal Cbpark { get; set; }
        public double? Ssurcharge { get; set; }
        public double? Csurcharge { get; set; }
        public decimal? Srateperadstop { get; set; }
        public decimal? Crateperadstop { get; set; }
        public decimal? Sadmenperhour { get; set; }
        public decimal? Cadmenperhour { get; set; }
        public decimal? Scoacharge { get; set; }
        public decimal? Ccoacharge { get; set; }
        public decimal? Sperhour { get; set; }
        public decimal? Cperhour { get; set; }
        public double? Sfmin { get; set; }
        public double? Cfmin { get; set; }
        public double? Sfcarton { get; set; }
        public double? Cfcarton { get; set; }
        public decimal? Sadcarton { get; set; }
        public decimal? Cadcarton { get; set; }
        public decimal? Sicharge { get; set; }
        public decimal? Cicharge { get; set; }
        public decimal? Sirate { get; set; }
        public decimal? Cirate { get; set; }
        public double? Sflb { get; set; }
        public double? Cflb { get; set; }
        public decimal? Sadlb { get; set; }
        public decimal? Cadlb { get; set; }
        public string Chargetoll { get; set; }
        public string Chargepark { get; set; }
        public double? Srtriprate { get; set; }
        public double? Crtriprate { get; set; }
        public string Ssrate { get; set; }
        public string Csrate { get; set; }
        public double? Sahrate { get; set; }
        public double? Cahrate { get; set; }
        public double? Ssatrate { get; set; }
        public double? Csatrate { get; set; }
        public double? Sholirate { get; set; }
        public double? Cholirate { get; set; }
        public double? Srushrate { get; set; }
        public string Srushtype { get; set; }
        public double? Sfmile { get; set; }
        public double? Cfmile { get; set; }
        public decimal? Sadmile { get; set; }
        public decimal? Cadmile { get; set; }
        public decimal? Sretreq { get; set; }
        public decimal? Cretreq { get; set; }
        public long Rowguid { get; set; }
        public double Stax { get; set; }
        public double Ctax { get; set; }
        public double? Ssunrate { get; set; }
        public double? Csunrate { get; set; }
    }
}
