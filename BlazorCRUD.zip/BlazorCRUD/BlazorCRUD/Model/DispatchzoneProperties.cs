﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class DispatchzoneProperties
    {
        public int Code { get; set; }
        public string Name { get; set; }
    }
}
