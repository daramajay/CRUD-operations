﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class CEmployeeProperties
    {
        public int Id { get; set; }
        public string Customerno { get; set; } // Need to get from Customermaintenance table
        public string Name { get; set; }
        public string Username { get; set; } //Unique
        public string Pwd { get; set; }
        public string Department { get; set; }
        public string Budget { get; set; }
        public string Customeref { get; set; }
        public string Workorder { get; set; }
        public string Phone { get; set; }
        public string Extension { get; set; }
        public string Email { get; set; }
        public string Lvel { get; set; }
        public string Company { get; set; }
        public string Street { get; set; }
        public string Flr { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zipcode { get; set; }
        public string Noticejo { get; set; }
        public string Noticejc { get; set; }
        public string Noticejs { get; set; }
        public bool Dpa { get; set; }
        public bool? Active { get; set; }
        public short Quantity { get; set; }
        public string Description { get; set; }
        public string Instruction { get; set; }
        public string Gcmid { get; set; }
        public bool TFa { get; set; }
        public int? RetryAttempts { get; set; }
        public bool IsLocked { get; set; }
        public DateTime? LockedDateTime { get; set; }
        public Guid Salt { get; set; } // Example: ae7387c3-348c-4faa-8ae5-949fdfbe59c4
        public string Pwdhash { get; set; }
    }
}
