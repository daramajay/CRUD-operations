﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomerpickupProperties
    {
        public string Customerno { get; set; } // get from the Customermaintenance table
        public string Name { get; set; }
        public string Street { get; set; }
        public string Zipcode { get; set; }
        public string Phone { get; set; }
        public string Extension { get; set; }
        public string Citystate { get; set; }
        public string Contact { get; set; }
        public string Flr { get; set; }
        public long Rowguid { get; set; }
        public string State { get; set; }
        public string Instruction { get; set; }
    }
}
