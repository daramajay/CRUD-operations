﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobProperties
    {
        public string Customerno { get; set; }
        public string Ticketno { get; set; } //Unique
        public string Jobno { get; set; } //Unique
        public string Psref { get; set; }
        public string Phone { get; set; }
        public string Extension { get; set; }
        public string Department { get; set; }
        public string Customeref { get; set; }
        public string Budget { get; set; }
        public string Workorder { get; set; }
        public string Servicetype { get; set; }
        public string Jobtype { get; set; }
        public string Routeno { get; set; }
        public string Pcompany { get; set; }
        public string Pflr { get; set; }
        public string Pphone { get; set; }
        public string Pextension { get; set; }
        public string Description { get; set; }
        public string Dcompany { get; set; }
        public string Dzipcode { get; set; }
        public string Dflr { get; set; }
        public string Dphone { get; set; }
        public string Dextension { get; set; }
        public string Rush { get; set; }
        public string Cod { get; set; }
        public short? Quantity { get; set; }
        public string Paddress { get; set; }
        public string Daddress { get; set; }
        public string Courier { get; set; }
        public string Pzipcode { get; set; }
        public string Remark { get; set; }
        public string Act { get; set; }
        public string Inv { get; set; }
        public DateTime Rdate { get; set; }
        public DateTime? Date { get; set; }
        public DateTime? Date2 { get; set; }
        public DateTime? Cdat { get; set; }
        public string Caller { get; set; }
        public string Pcontact { get; set; }
        public string Dcontact { get; set; }
        public double? Miles { get; set; }
        public double? Weight { get; set; }
        public string Instruction { get; set; }
        public string Pickupby { get; set; }
        public string Operator { get; set; }
        public string Zonecode { get; set; }
        public string Dzone { get; set; }
        public string Mailroute { get; set; }
        public string Rtime { get; set; }
        public string Time { get; set; }
        public string Time2 { get; set; }
        public string Tosale { get; set; }
        public string Doffice { get; set; }
        public bool Reqreturn { get; set; }
        public bool Oz { get; set; }
        public long Rowguid { get; set; }
        public string Pclass { get; set; }
        public string Dclass { get; set; }
        public bool Fup { get; set; }
        public DateTime Deldate { get; set; }
        public string Deltime { get; set; }
        public bool FlUp { get; set; }
        public decimal Dvalue { get; set; }
        public bool SigRq { get; set; }
        public bool? Billable { get; set; }
        public string Pcity { get; set; }
        public string Pstate { get; set; }
        public string Dcity { get; set; }
        public string Dstate { get; set; }
        public string Pd { get; set; }
        public string Mticketno { get; set; }
        public bool Exc { get; set; }
        public string Zonedisp { get; set; }
        public string PlatLng { get; set; }
        public string DlatLng { get; set; }
        public string Actcode { get; set; }
        public bool Presi { get; set; }
        public bool Dresi { get; set; }
        public string Warehouse { get; set; }
        public string Pono { get; set; }
        public string Cono { get; set; }
        public string Stopno { get; set; }
        public bool HasToll { get; set; }
        public string Dcontact2 { get; set; }
        public string Pwin { get; set; }
        public string Dwin { get; set; }
        public string Pinstruction { get; set; }
        public string Dinstruction { get; set; }
        public string Latlng { get; set; }
        public string Psignature { get; set; }
        public string Dsignature { get; set; }
        public string Phonetype { get; set; }
        public string Bycourier { get; set; }
        public DateTime? Pstart { get; set; }
        public DateTime? Pend { get; set; }
        public DateTime? Dstart { get; set; }
        public DateTime? Dend { get; set; }
        public string Location { get; set; }
        public int? Unit { get; set; }
        public string Pemail { get; set; }
        public string Demail { get; set; }
        public DateTime? Readydate { get; set; }
        public string Readytime { get; set; }
    }
}
