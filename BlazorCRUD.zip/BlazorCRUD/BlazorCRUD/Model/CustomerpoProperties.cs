﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomerpoProperties
    {
        public string Pno { get; set; }
        public string Customerno { get; set; } // get from the Customermaintenance table
        public string Cno { get; set; }
        public DateTime? Posdate { get; set; }
        public DateTime? Poedate { get; set; }
        public decimal? Amount { get; set; }
        public decimal? Sptamount { get; set; }
        public string Note { get; set; }
        public bool? Active { get; set; }
        public long Rowguid { get; set; }
        public string Description { get; set; }
    }
}
