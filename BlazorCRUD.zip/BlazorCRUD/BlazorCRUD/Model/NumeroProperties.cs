﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class NumeroProperties
    {
        public string Ticket { get; set; }
        public string Inv { get; set; }
        public string Ref { get; set; }
        public string Qtref { get; set; }
        public string Wticket { get; set; }
        public DateTime? Paydate { get; set; }
        public string Caseref { get; set; }
        public long Rowguid { get; set; }
    }
}
