﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class RoutemaintenanceProperties
    {
        public string Routeno { get; set; } //Unique
        public string Courieridno { get; set; }
        public string Courieridno2 { get; set; }
        public string Description { get; set; }
        public DateTime Sdate { get; set; }
        public DateTime? Edate { get; set; }
        public bool? Active { get; set; }
        public string Email { get; set; }
    }
}
