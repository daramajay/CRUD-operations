﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobpackageProperties
    {
        public string Customerno { get; set; }
        public string Ticketno { get; set; }
        public int Quantity { get; set; }
        public string Type { get; set; }
        public long Rowguid { get; set; }
        public string Alias { get; set; }
        public int? Aliascount { get; set; }
        public string Description { get; set; }
        public double? Weight { get; set; }
        public double? Height { get; set; }
        public double? Width { get; set; }
        public double? Length { get; set; }
        public string Jpact { get; set; }
        public DateTime Jpdate { get; set; }
        public string Jpactcode { get; set; }
        public bool Exception { get; set; }
        public string Latlng { get; set; }
    }
}
