﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobnoteProperties
    {
        public string Customerno { get; set; }
        public string Ticketno { get; set; }
        public DateTime Date { get; set; }
        public string Time { get; set; }
        public string Operator { get; set; }
        public string Note { get; set; }
        public long Rowguid { get; set; }
        public string Act { get; set; }
        public string Type { get; set; }
        public string Geotag { get; set; }
        public string Contenttype { get; set; }
        public byte[] Content { get; set; } //Varbinary in sql
        public string Contentname { get; set; }
        public bool Cview { get; set; }
    }
}
