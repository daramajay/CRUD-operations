﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class TsmaintenanceProperties
    {
        public string Customerno { get; set; } // get from Customermaintenance table
        public string Inv { get; set; }
        public string Tosale { get; set; }
        public DateTime? Date { get; set; }
        public DateTime? Cdat { get; set; }
        public string Courieridno { get; set; } // get from Couriermastermaintenance table
        public double? Rtime { get; set; }
        public double? Otime { get; set; }
        public double? Nh { get; set; }
        public double? Otf { get; set; }
        public decimal? Rcharge { get; set; }
        public decimal? Ocharge { get; set; }
        public decimal? Expense { get; set; }
        public decimal? Tcharge { get; set; }
        public decimal? Hrate { get; set; }
        public string Couriername { get; set; }
        public string Operunit { get; set; }
        public string Costcenter { get; set; }
        public string Voucher { get; set; }
        public string Servicetype { get; set; }
        public long Rowguid { get; set; }
        public decimal Taxcharge { get; set; }
    }
}
