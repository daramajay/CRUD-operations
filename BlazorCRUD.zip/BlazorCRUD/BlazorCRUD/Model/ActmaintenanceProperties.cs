﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class ActmaintenanceProperties
    {
        

        public string Id { get; set; }
        public string Act { get; set; }
        public string Actgroup { get; set; }
        public bool? Active { get; set; }
        public bool? Iscourier { get; set; }
        public string Mask { get; set; }
        public bool? Ispaid { get; set; }
        public string Description { get; set; }

    }

}
