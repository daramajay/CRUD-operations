﻿using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class BillFromCompanyProperties
    {
        [Key]
        public long rowguid { get; set; }
        public string NAME { get; set; }
        public string PHONE { get; set; }
        public string STREET { get; set; }
        public string ZIPCODE { get; set; }
        public string COMPNO { get; set; }
        public string DEFCOMP { get; set; }
        public string CITYSTATE { get; set; }
        public string STATE { get; set; }
        public bool ACTIVE { get; set; }
    }
}
