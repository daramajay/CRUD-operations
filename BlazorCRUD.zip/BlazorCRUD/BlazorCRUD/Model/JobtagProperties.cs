﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobtagProperties
    {
        public string Ticketno { get; set; } //get from the Job table
        public string Tagname { get; set; } //get from the Tagmaintenance table
        public long Id { get; set; }
    }
}
