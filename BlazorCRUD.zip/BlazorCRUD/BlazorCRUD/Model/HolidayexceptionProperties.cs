﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class HolidayexceptionProperties
    {
        public int Id { get; set; }
        public string Customerno { get; set; } //Need to get from Customermaintenance table
        public DateTime Date { get; set; } //Need to get from Holiday table
    }
}
