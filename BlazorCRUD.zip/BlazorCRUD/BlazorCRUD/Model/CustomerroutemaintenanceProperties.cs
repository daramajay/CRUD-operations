﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomerroutemaintenanceProperties
    {
        public string Customerno { get; set; } // Get from the Customermaintenance table
        public int? Id { get; set; }
        public string Routeno { get; set; }
        public string Stopno { get; set; }
        public string Company { get; set; }
        public string Zipcode { get; set; }
        public string Flr { get; set; }
        public string Phone { get; set; }
        public string Extension { get; set; }
        public string Address { get; set; }
        public string Contact { get; set; }
        public long Rowguid { get; set; }
        public string Instruction { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Mailroute { get; set; }
        public string Email { get; set; }
    }
}
