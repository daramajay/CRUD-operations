﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobreceiptProperties
    {
        public int Id { get; set; }
        public string Ticketno { get; set; } //get from the Job table and it will be unique
        public DateTime? Parrival { get; set; }
        public DateTime? Pdeparture { get; set; }
        public DateTime? Darrival { get; set; }
        public DateTime? Ddeparture { get; set; }
        public string Psignedby { get; set; }
        public string Dsignedby { get; set; }
        public string Psignature { get; set; }
        public string Dsignature { get; set; }
        public int? Quantity { get; set; }
        public int? Pquantity { get; set; }
        public int? Dquantity { get; set; }
        public string Pcode { get; set; }
        public string Dcode { get; set; }
        public int? Pbag { get; set; }
        public int? Dbag { get; set; }
        public bool Item1to150 { get; set; }
        public bool Item151to500 { get; set; }
        public bool Itemover500 { get; set; }
        public bool Addlhour { get; set; }
        public string Addlsupply { get; set; }
        public bool Psigned { get; set; }
        public bool Dsigned { get; set; }
        public int? Pebag { get; set; }
        public int? Debag { get; set; }
        public string Daddlsupply { get; set; }
    }
}
