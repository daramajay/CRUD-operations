﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomerefmaintenanceProperties
    {
        public string Customerno { get; set; } // Need to get from Customermaintenance table
        public string Customeref { get; set; }
        public string Customerefname { get; set; }
        public string Department { get; set; }
        public string Budget { get; set; }
        public string Workorder { get; set; }
        public long Rowguid { get; set; }
    }
}
