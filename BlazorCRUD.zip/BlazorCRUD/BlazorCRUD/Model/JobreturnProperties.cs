﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobreturnProperties
    {
        public string Customerno { get; set; } // get from Customermaintenance table
        public string Ticketno { get; set; } // get from Job table
        public DateTime Date { get; set; }
        public string Time { get; set; }
        public string Refno { get; set; }
        public long Id { get; set; }
    }
}
