﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class HolidayProperties
    {
        public int Id { get; set; }
        public DateTime Date { get; set; } //Part of Key...so cannot modified
        public string Name { get; set; }
        public string Note { get; set; }
    }
}
