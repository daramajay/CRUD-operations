﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class ContactMaintenanceProperties
    {
        public string Customerno { get; set; }
        public long? Rid { get; set; }
        public string Contact { get; set; }
        public string Phone { get; set; }
        public string Extension { get; set; }
        public string Email { get; set; }
        public long Rowguid { get; set; }
    }
}
