﻿using BlazorCRUD.Pages;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class ActCodeMaintenanceProperties
    {

        public string Id { get; set; }
        public string Act { get; set; }
        public string Reason { get; set; }
        public string Description { get; set; }
        public bool? Iscourier { get; set; }

    }
}
