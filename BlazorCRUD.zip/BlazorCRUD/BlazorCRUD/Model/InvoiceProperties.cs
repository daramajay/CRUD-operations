﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class InvoiceProperties
    {
        public string Inv { get; set; }
        public string Customerno { get; set; }
        public DateTime Idate { get; set; }
        public decimal Surdiscount { get; set; }
        public string Description { get; set; }
        public double Csurdiscount { get; set; }
        public DateTime? Sdate { get; set; }
        public decimal? Samount { get; set; }
        public double Tax { get; set; }
        public double Ctax { get; set; }
        public string Ipo { get; set; }
        public string Ico { get; set; }
        public decimal? Ipoamt { get; set; }
        public decimal? Icoamt { get; set; }
        public string Note { get; set; }
        public DateTime? Iposdate { get; set; }
        public DateTime? Ipoedate { get; set; }
        public DateTime? Icosdate { get; set; }
        public DateTime? Icoedate { get; set; }
        public string Iname { get; set; }
        public string Iaddress { get; set; }
        public string Icity { get; set; }
        public string Istate { get; set; }
        public string Iflr { get; set; }
        public string Izipcode { get; set; }
        public string Icontact { get; set; }
        public string Iphone { get; set; }
    }
}
