﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class LocationmaintenanceProperties
    {
        public long Rowguid { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
