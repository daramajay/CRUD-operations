﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class CourierRouteProperties
    {
        public int Id { get; set; }
        public string Courieridno { get; set; } //from Couriermastermaintenance
        public string Customerno { get; set; }
        public string Routeref { get; set; }
        public string Route { get; set; }
        public bool Dispatch { get; set; }
    }
}
