﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class ChargeCodeProperties
    {
        public string Code { get; set; } //It will be unique
        public string Glnum { get; set; }
        public string Gldesc { get; set; }
        public string Codedesc { get; set; }
        public long Rowguid { get; set; }
    }
}
