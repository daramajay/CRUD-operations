﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class PwdtabProperties
    {
        public string Pwd { get; set; }
        public string Lvel { get; set; }
        public string Name { get; set; }
        public string Usname { get; set; } //It will be unique
        public string Compused { get; set; }
        public string Department { get; set; }
        public string Email { get; set; }
        public bool? Active { get; set; }
        public bool Connected { get; set; }
        public bool Lexception { get; set; }
        public string Location { get; set; }
        public bool? Webactive { get; set; }
        public bool Chargeaccess { get; set; }
        public long Rowguid { get; set; } //auto Generated
        public bool Adminrepaccess { get; set; }
        public bool Smsaccess { get; set; }
        public string Note { get; set; }
        public string Appused { get; set; }
        public bool Costaccess { get; set; }
        public bool Delcostaccess { get; set; }
        public bool Rabnote { get; set; }
        public bool Rcbnote { get; set; }
        public bool? Svcaccess { get; set; }
        public DateTime? Logintime { get; set; }
        public bool Chargeviewaccess { get; set; }
        public bool Costviewaccess { get; set; }
        public Guid Salt { get; set; } //auto Generated
        public byte[] Pwdhash { get; set; }
    }
}
