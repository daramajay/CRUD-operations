﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class SalesfacttableProperties
    {
        public int Id { get; set; }
        public string Invoice { get; set; }
        public DateTime Date { get; set; }
        public string Service { get; set; }
        public string Customer { get; set; }
        public string Location { get; set; }
        public string BranchOffice { get; set; }
        public string SalesPerson { get; set; }
        public string CourierCompany { get; set; }
        public int? NoOfJobs { get; set; }
        public decimal? Amount { get; set; }
    }
}
