﻿using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class GroupAccountProperties
    {
        [Key]
        public long GANO { get; set; }
        public string ZIPCODE { get; set; }
        [Required(ErrorMessage = "Phone Number is required field")]
        public string PHONE { get; set; }
        public string EMAIL { get; set; }
        public string PRINTER { get; set; }
        public string PORT { get; set; }
        [Required(ErrorMessage = "Address Number is required field")]
        public string ADDRESS { get; set; }
        [Required(ErrorMessage = "Name is required field")]
        public string NAME { get; set; }
        [Required(ErrorMessage = "State is required field")]
        public string STATE { get; set; }
        public string ZONECODE { get; set; }
        public string AREA { get; set; }
        public string City { get; set; }
        public bool ACTIVE { get; set; }
    }
}
