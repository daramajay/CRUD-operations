﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomermaintenanceProperties
    {
        public string Customerno { get; set; } //Unique
        public string Compno { get; set; }
        public string Street { get; set; }
        public string Citystate { get; set; }
        public string Ustate { get; set; }
        public string State { get; set; }
        public string Zipcode { get; set; }
        public string Phone { get; set; }
        public string Extension { get; set; }
        public string Termcode { get; set; }
        public string Departmentbreak { get; set; }
        public string Faxno { get; set; }
        public string Rhfrom { get; set; }
        public string Rhto { get; set; }
        public string Mhour { get; set; }
        public string Barcodedticket { get; set; }
        public string Billfrequency { get; set; }
        public string Manifesttype { get; set; }
        public bool Manifestbf { get; set; }
        public string Invoicetype { get; set; }
        public string Depsetup { get; set; }
        public string Cstatusflag { get; set; }
        public string Shuttleactivity { get; set; }
        public string Pagebreak { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public decimal Bval { get; set; }
        public decimal Rate { get; set; }
        public decimal? Creditlimit { get; set; }
        public decimal? Hrate { get; set; }
        public double? Surchargediscount { get; set; }
        public string Salesmanno { get; set; }
        public string Name { get; set; }
        public string Servicetype { get; set; }
        public string Gaccountno { get; set; }
        public decimal? Currentamount { get; set; }
        public decimal Pass30 { get; set; }
        public decimal Pass60 { get; set; }
        public decimal Pass90 { get; set; }
        public decimal Over90 { get; set; }
        public string Flr { get; set; }
        public string Operator { get; set; }
        public string Po { get; set; }
        public string Upsflag { get; set; }
        public double Upsdisc { get; set; }
        public string Fdxflag { get; set; }
        public double Fdxdisc { get; set; }
        public string Dhlflag { get; set; }
        public double Dhldisc { get; set; }
        public string Bnote { get; set; }
        public long Rowguid { get; set; }
        public bool Ozflag { get; set; }
        public string Wsflag { get; set; }
        public bool? Active { get; set; }
        public bool? Newflag { get; set; }
        public bool Hotflag { get; set; }
        public double Tax { get; set; }
        public bool Taxflag { get; set; }
        public DateTime Odate { get; set; }
        public string Mcustomerno { get; set; }
        public string Taxtype { get; set; }
        public bool Billflag { get; set; }
        public string Url { get; set; }
        public string Co { get; set; }
        public decimal? Poamt { get; set; }
        public decimal? Coamt { get; set; }
        public DateTime? Posdate { get; set; }
        public DateTime? Poedate { get; set; }
        public DateTime? Cosdate { get; set; }
        public DateTime? Coedate { get; set; }
        public string Uspsflag { get; set; }
        public double Uspsdisc { get; set; }
        public string Cjobtype { get; set; }

        public byte[] Logo { get; set; }
        public bool? Agingrp { get; set; }
        public string Upsaccount { get; set; }
        public string Fdxaccount { get; set; }
    }
}
