﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomerpricescheduleProperties
    {
        public string Customerno { get; set; } //get from the Customermaintenance table
        public string Servicetype { get; set; } //get from the Servicemaintenance table
        public string Billingtype { get; set; }
        public string Zonecode { get; set; } //get from the Zonemastermaintenance table
        public string Citytown { get; set; }
        public string State { get; set; }
        public decimal? Jobcostdriver { get; set; }
        public decimal? Jobcostscotter { get; set; }
        public decimal? Jobcostbiker { get; set; }
        public decimal? Jobcostmesg { get; set; }
        public decimal? Brate { get; set; }
        public decimal? Bfare { get; set; }
        public decimal? Btoll { get; set; }
        public long Rowguid { get; set; }
        public decimal? Jobcostcartmesg { get; set; }
        public decimal? Jobcostondmesg { get; set; }
    }
}
