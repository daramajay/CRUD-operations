﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomerpackageProperties
    {
        public string Customerno { get; set; } // Need to get from Customermaintenance table
        public string Description { get; set; }
        public long Rowguid { get; set; }
    }
}
