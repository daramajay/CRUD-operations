﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class CF_descProperties
    {
        public string Customerno { get; set; } // Need to get from Customermaintenance table
        public string Ipwd { get; set; }
        public string Pwd { get; set; }
        public string Department { get; set; }
        public string Customeref { get; set; }
        public string Budget { get; set; }
        public string Workorder { get; set; }
        public string Email { get; set; }
        public bool Deptval { get; set; }
        public bool Bgtval { get; set; }
        public long Rowguid { get; set; }
    }
}
