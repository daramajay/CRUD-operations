﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobprodProperties
    {
        public string Customerno { get; set; }
        public string Ticketno { get; set; }
        public string Charge { get; set; }
        public decimal Amount { get; set; }
        public long Rowguid { get; set; }
    }
}
