﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobchargeProperties
    {
        public string Customerno { get; set; }
        public string Ticketno { get; set; }
        public string Charge { get; set; }
        public decimal? Base { get; set; }
        public decimal? Quantity { get; set; }
        public string Particular { get; set; }
        public decimal? Rate { get; set; }
        public decimal? Amount { get; set; }
        public decimal? Ext { get; set; }
        public long Rowguid { get; set; }
    }
}
