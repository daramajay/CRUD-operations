﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class CourierCommissionProperties
    {
        public long Id { get; set; }
        public string Courieridno { get; set; }
        public DateTime Fdate { get; set; }
        public DateTime Tdate { get; set; }
        public string Filepath { get; set; }
        public DateTime Filedate { get; set; }
    }
}
