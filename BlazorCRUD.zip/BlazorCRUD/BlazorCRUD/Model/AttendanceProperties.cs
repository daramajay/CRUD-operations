﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class AttendanceProperties
    {
        public long Rowguid { get; set; }
        public string Courieridno { get; set; } //get from the Couriermastermaintenance table
        public DateTime Date { get; set; }
        public string Signin { get; set; }
        public string SigninGeotag { get; set; }
        public string Signout { get; set; }
        public string SignoutGeotag { get; set; }
        public string Operator { get; set; }
        public string Note { get; set; }
        public string Schedin { get; set; }
        public string Schedout { get; set; }
    }
}
