﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class ServiceMaintenanceProperties
    {
        public string Id { get; set; } //Unique
        public string Servicetype { get; set; } //Unique
        public string Mask { get; set; }
        public string Parentid { get; set; }
        public bool? Web { get; set; }
        public string Agent { get; set; }
        public string Agentidno { get; set; }
        public bool? Active { get; set; }
    }
}
