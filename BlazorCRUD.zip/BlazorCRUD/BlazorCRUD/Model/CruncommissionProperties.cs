﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CruncommissionProperties
    {
        public int Id { get; set; }
        public string Courieridno { get; set; }
        public string Couriername { get; set; }
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        public DateTime Date { get; set; }
        public decimal Amount { get; set; }
    }
}
