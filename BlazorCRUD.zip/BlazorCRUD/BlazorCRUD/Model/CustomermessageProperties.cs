﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomermessageProperties
    {
        public string Customerno { get; set; } // Need to get from Customermaintenance table
        public string Jobtype { get; set; }
        public string Email { get; set; }
        public string Sms { get; set; }
        public long Rowguid { get; set; }
    }
}
