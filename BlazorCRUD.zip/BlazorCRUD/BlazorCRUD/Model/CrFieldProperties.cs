﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class CrFieldProperties
    {
        public string Customerno { get; set; } //get from the Customermaintenance table
        public string Caller { get; set; }
        public string Phone { get; set; }
        public string Extension { get; set; }
        public string Department { get; set; }
        public string Customeref { get; set; }
        public string Budget { get; set; }
        public string Workorder { get; set; }
        public string Servicetype { get; set; }
        public string Jobtype { get; set; }
        public string Routeno { get; set; }
        public string Pcompany { get; set; }
        public string Pcontact { get; set; }
        public string Pickupby { get; set; }
        public string Pflr { get; set; }
        public string Pphone { get; set; }
        public string Pextension { get; set; }
        public string Description { get; set; }
        public string Instruction { get; set; }
        public string Weight { get; set; }
        public string Dcompany { get; set; }
        public string Dzipcode { get; set; }
        public string Dcontact { get; set; }
        public string Dflr { get; set; }
        public string Dphone { get; set; }
        public string Dextension { get; set; }
        public string Zonecode { get; set; }
        public string Miles { get; set; }
        public string Rush { get; set; }
        public string Cod { get; set; }
        public string Quantity { get; set; }
        public string Paddress { get; set; }
        public string Daddress { get; set; }
        public string Pzipcode { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string Dcharge { get; set; }
        public string Note { get; set; }
        public string Job { get; set; }
        public string Pod { get; set; }
        public string Email { get; set; }
        public long Rowguid { get; set; }
        public string Dvalue { get; set; }
        public string Dcontact2 { get; set; }
        public string Pinstruction { get; set; }
        public string Dinstruction { get; set; }
        public bool? Showcustomerno { get; set; }
        public bool? Showcaller { get; set; }
        public bool? Showphone { get; set; }
        public bool? Showextension { get; set; }
        public bool? Showdepartment { get; set; }
        public bool? Showcustomeref { get; set; }
        public bool? Showbudget { get; set; }
        public bool? Showworkorder { get; set; }
        public bool? Showservicetype { get; set; }
        public bool? Showjobtype { get; set; }
        public bool? Showrouteno { get; set; }
        public bool? Showpcompany { get; set; }
        public bool? Showpcontact { get; set; }
        public bool? Showpickupby { get; set; }
        public bool? Showpflr { get; set; }
        public bool? Showpphone { get; set; }
        public bool? Showpextension { get; set; }
        public bool? Showdescription { get; set; }
        public bool? Showinstruction { get; set; }
        public bool? Showweight { get; set; }
        public bool? Showdcompany { get; set; }
        public bool? Showdzipcode { get; set; }
        public bool? Showdcontact { get; set; }
        public bool? Showdflr { get; set; }
        public bool? Showdphone { get; set; }
        public bool? Showdextension { get; set; }
        public bool? Showzonecode { get; set; }
        public bool? Showmiles { get; set; }
        public bool? Showrush { get; set; }
        public bool? Showcod { get; set; }
        public bool? Showquantity { get; set; }
        public bool? Showpaddress { get; set; }
        public bool? Showdaddress { get; set; }
        public bool? Showpzipcode { get; set; }
        public bool? Showdate { get; set; }
        public bool? Showtime { get; set; }
        public bool? Showdvalue { get; set; }
        public bool? Showdcontact2 { get; set; }
        public bool? Showpinstruction { get; set; }
        public bool? Showdinstruction { get; set; }
        public bool Showlogo { get; set; }
        public bool? Shownote { get; set; }
        public string Pcity { get; set; }
        public string Pstate { get; set; }
        public string Dcity { get; set; }
        public string Dstate { get; set; }
        public bool? Showpcity { get; set; }
        public bool? Showpstate { get; set; }
        public bool? Showdcity { get; set; }
        public bool? Showdstate { get; set; }
        public bool Showupload { get; set; }
        public string Picsign { get; set; }
    }
}
