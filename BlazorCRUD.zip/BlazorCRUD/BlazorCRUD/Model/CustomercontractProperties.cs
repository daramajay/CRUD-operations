﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomercontractProperties
    {
        public int Id { get; set; }
        public string Cno { get; set; }
        public string Customerno { get; set; } // Need to get from Customermaintenance
        public DateTime? Cosdate { get; set; }
        public DateTime? Coedate { get; set; }
        public decimal? Amount { get; set; }
        public decimal? Sptamount { get; set; }
        public string Note { get; set; }
        public bool? Active { get; set; }
        public string Description { get; set; }
    }
}
