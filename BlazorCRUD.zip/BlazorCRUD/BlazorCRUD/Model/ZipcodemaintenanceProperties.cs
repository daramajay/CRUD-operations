﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class ZipcodemaintenanceProperties
    {
        public string Zipcode { get; set; } //Unique
        public string Zonecode { get; set; }
        public string Dzone { get; set; }
        public string State { get; set; }
        public string Citytown { get; set; }
        public long Rowguid { get; set; }
    }
}
