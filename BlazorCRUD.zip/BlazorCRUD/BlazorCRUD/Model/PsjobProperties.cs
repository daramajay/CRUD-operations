﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class PsjobProperties
    {
        public string Psref { get; set; }
        public string Customerno { get; set; }
        public string Ticket { get; set; }
        public string Caller { get; set; }
        public string Phone { get; set; }
        public string Extension { get; set; }
        public string Department { get; set; }
        public string Customeref { get; set; }
        public string Budget { get; set; }
        public string Workorder { get; set; }
        public string Servicetype { get; set; }
        public string Jobtype { get; set; }
        public string Routeno { get; set; }
        public string Pcompany { get; set; }
        public string Pzipcode { get; set; }
        public string Pflr { get; set; }
        public string Pphone { get; set; }
        public string Pextension { get; set; }
        public string Description { get; set; }
        public string Dcompany { get; set; }
        public string Dzipcode { get; set; }
        public string Dflr { get; set; }
        public string Dphone { get; set; }
        public string Dextension { get; set; }
        public string Rush { get; set; }
        public string Cod { get; set; }
        public short? Quantity { get; set; }
        public string Paddress { get; set; }
        public string Daddress { get; set; }
        public string Sched { get; set; }
        public string Office { get; set; }
        public string Btime { get; set; }
        public string Pcontact { get; set; }
        public string Dcontact { get; set; }
        public double? Miles { get; set; }
        public double? Weight { get; set; }
        public string Instruction { get; set; }
        public string Pickupby { get; set; }
        public string Mailroute { get; set; }
        public string Zonecode { get; set; }
        public DateTime? Date { get; set; }
        public string Status { get; set; }
        public string Courier { get; set; }
        public string Dzone { get; set; }
        public string Doffice { get; set; }
        public long Rowguid { get; set; }
        public string Pclass { get; set; }
        public string Dclass { get; set; }
        public DateTime? Sdate { get; set; }
        public DateTime? Edate { get; set; }
        public bool Pay { get; set; }
        public decimal? Payamount { get; set; }
        public string Pwin { get; set; }
        public string Dwin { get; set; }
        public string Pinstruction { get; set; }
        public string Dinstruction { get; set; }
        public string Deltime { get; set; }
        public string Delsched { get; set; }
        public string Zonedisp { get; set; }
        public DateTime? Rundate { get; set; }
        public string Pcity { get; set; }
        public string Pstate { get; set; }
        public string Dcity { get; set; }
        public string Dstate { get; set; }
    }
}
