﻿using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD
{
    public class SalesmanProperties
    {
        public string Salesmanno { get; set; }
        public string Salesmanname { get; set; }
        public string Cphone { get; set; }
        public string Hphone { get; set; }
        public string Email { get; set; }
        public long Rowguid { get; set; }
        public bool Active { get; set; }
    }
}
