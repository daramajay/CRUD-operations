﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class ZonemastermaintenanceProperties
    {
        public string Zonecode { get; set; } //Unique
        public double? Avmileage { get; set; }
        public decimal? Standardtoll { get; set; }
        public string Citytown { get; set; }
        public string State { get; set; }
        public long Rowguid { get; set; }
        public string Zipcodelist { get; set; }
    }
}
