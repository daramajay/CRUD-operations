﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class CallermaintenancePropertice
    {
        public int Id { get; set; }
        public string Customerno { get; set; } //Need to get from Customermaintenance tbale
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Extension { get; set; }
        public string Email { get; set; }
        public string Username { get; set; }
    }
}
