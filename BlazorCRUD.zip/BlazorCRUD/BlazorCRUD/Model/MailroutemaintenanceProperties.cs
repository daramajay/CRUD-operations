﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class MailroutemaintenanceProperties
    {
        public string Mrno { get; set; } //Unique
        public string Name { get; set; }
        public string Description { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public long Rowguid { get; set; }
    }
}
