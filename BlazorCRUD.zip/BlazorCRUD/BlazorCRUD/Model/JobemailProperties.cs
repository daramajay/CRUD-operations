﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobemailProperties
    {
        public string Customerno { get; set; }
        public string Ticketno { get; set; }
        public string Act { get; set; }
        public string Subject { get; set; }
        public string Email { get; set; }
        public bool Emailed { get; set; }
        public DateTime? Date { get; set; }
        public long Rowguid { get; set; }
        public string Phone { get; set; }
        public bool Phoned { get; set; }
    }
}
