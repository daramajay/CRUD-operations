﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobcostProperties
    {
        public string Customerno { get; set; }
        public string Ticketno { get; set; }
        public string Ddate { get; set; }
        public string Courieridno { get; set; }
        public decimal? Base { get; set; }
        public decimal? Waitime { get; set; }
        public decimal? Adstop { get; set; }
        public decimal? Admen { get; set; }
        public decimal Admile { get; set; }
        public decimal? Shuttle { get; set; }
        public decimal? Amount { get; set; }
        public string Tosale { get; set; }
        public long Rowguid { get; set; }
        public string Mcourieridno { get; set; }
        public DateTime? Datetosale { get; set; }
    }
}
