﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class ClassDispatchProperties
    {
        public string Code { get; set; } //unique
        public string Name { get; set; } //unique
    }
}
