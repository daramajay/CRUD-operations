﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BlazorCRUD.Model
{
    public class BudgetmaintenanceProperties
    {
        public string Customerno { get; set; } //Need to get from Customermaintenance tbale
        public string Budget { get; set; }
        public string Budgetname { get; set; }
        public string Department { get; set; }
        public string Customeref { get; set; }
        public string Workorder { get; set; }
        public long Rowguid { get; set; }
        public bool? Active { get; set; }
    }
}
