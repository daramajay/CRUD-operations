﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class StandardpricemaintenanceProperties
    {
        public string Billingtype { get; set; }
        public string Zonecode { get; set; }
        public string Servicetype { get; set; }
        public string Citytown { get; set; }
        public string State { get; set; }
        public decimal? Brate { get; set; }
        public decimal? Bfare { get; set; }
        public decimal? Jobcostdriver { get; set; }
        public decimal? Jobcostbiker { get; set; }
        public decimal? Jobcostmesg { get; set; }
        public long Rowguid { get; set; }
    }
}
