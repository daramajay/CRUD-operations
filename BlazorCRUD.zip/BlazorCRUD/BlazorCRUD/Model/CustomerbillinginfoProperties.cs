﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class CustomerbillinginfoProperties
    {
        public string Customerno { get; set; } //Need to get from Customermaintenance table
        public string Street { get; set; }
        public string Flr { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zipcode { get; set; }
        public string Contact { get; set; }
        public string Phone { get; set; }
        public string Name { get; set; }
    }
}
