﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorCRUD.Model
{
    public class JobaddressProperties
    {
        public long Rowguid { get; set; }
        public string Ticketno { get; set; } //get from the Job table
        public string Paddress { get; set; }
        public string Platlng { get; set; }
        public bool Presi { get; set; }
        public string Daddress { get; set; }
        public string Dlatlng { get; set; }
        public bool Dresi { get; set; }
        public int Ok { get; set; }
    }
}
