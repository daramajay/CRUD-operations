﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using System.Threading;

namespace BlazorCRUD.Services
{
    public class SalesEntryService
    {
        private SalesmanProperties[] salesList;
        HttpClient client = new HttpClient();
        public async Task<IEnumerable<SalesmanProperties>> SalesmenList(CancellationToken ct = default)
        {
            HttpResponseMessage response = client.GetAsync("http://localhost:63919/api/GetBillfromcompanyInfo").Result;

            var responseAsString = await response.Content.ReadAsStringAsync();
            salesList = JsonConvert.DeserializeObject<SalesmanProperties[]>(responseAsString);
            return await Task.FromResult(salesList);
        }
    }
}
