﻿using BlazorCRUD.Model;
using Microsoft.EntityFrameworkCore;

namespace BlazorCRUD.Data
{
    public class SqlDbContext : DbContext
    {
        public SqlDbContext(DbContextOptions<SqlDbContext> options) : base(options)
        {
        }
        public DbSet<SalesmanProperties> tblsalesman { get; set; }
        public DbSet<GroupAccountProperties> tblGroupAccount { get; set; }
        public DbSet<BillFromCompanyProperties> tblBillFromCompany { get; set; }
    }
}
