﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BlazorCRUD.Data
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalesmanController : ControllerBase
    {
            private readonly SqlDbContext _context;

            public SalesmanController(SqlDbContext context)
            {
                _context = context;
            }

            [HttpGet]
            [Route("Get")]
            public async Task<ActionResult<IEnumerable<SalesmanProperties>>> Get()
            {
                return await _context.tblsalesman.ToListAsync();
            }

            [HttpPost]
            [Route("Insert")]
            public async Task<Response> Insert([FromBody] SalesmanProperties model)
            {
                Response _objResponse = new Response();
                try
                {
                    if (ModelState.IsValid)
                    {
                        _context.Add(model);
                        await _context.SaveChangesAsync();
                        _objResponse.Status = "Success";
                        _objResponse.Data = null;
                    }
                    else
                    {
                        _objResponse.Status = "Validation Error";
                        _objResponse.Data = null;
                    }
                }
                catch (Exception ex)
                {
                    _objResponse.Data = null;
                    _objResponse.Status = ex.Message;
                    Console.WriteLine("\nMessage ---\n{0}", ex.Message);
                    Console.WriteLine("\nStackTrace ---\n{0}", ex.StackTrace);
                }
                return _objResponse;
            }

            [HttpGet]
            [Route("Edit/{id}")]
            public async Task<SalesmanProperties> Edit(long id)
            {
                return await _context.tblsalesman.FindAsync(id);
            }

            [HttpPut]
            [Route("Update/{id}")]
            public async Task<Response> Update(long id, [FromBody] SalesmanProperties model)
            {
                Response _objResponse = new Response();
                try
                {
                    if (id != model.Rowguid)
                    {
                        _objResponse.Status = "No record found";
                        _objResponse.Data = null;
                    }
                    else
                    {
                        _context.Entry(model).State = EntityState.Modified;
                        await _context.SaveChangesAsync();
                        _objResponse.Status = "Success";
                        _objResponse.Data = null;
                    }
                }
                catch (Exception ex)
                {
                    _objResponse.Data = null;
                    _objResponse.Status = ex.Message;
                    Console.WriteLine("\nMessage ---\n{0}", ex.Message);
                    Console.WriteLine("\nStackTrace ---\n{0}", ex.StackTrace);
                }
                return _objResponse;
            }

            [HttpDelete]
            [Route("Delete/{id}")]
            public async Task<Response> Delete(long id)
            {
                Response _objResponse = new Response();
                try
                {
                    var category = await _context.tblsalesman.FindAsync(id);
                    if (category == null)
                    {
                        _objResponse.Status = "No record found";
                        _objResponse.Data = null;
                    }
                    else
                    {
                        _context.tblsalesman.Remove(category);
                        await _context.SaveChangesAsync();
                        _objResponse.Status = "Success";
                        _objResponse.Data = null;
                    }
                }
                catch (Exception ex)
                {
                    _objResponse.Data = null;
                    _objResponse.Status = ex.Message;
                    Console.WriteLine("\nMessage ---\n{0}", ex.Message);
                    Console.WriteLine("\nStackTrace ---\n{0}", ex.StackTrace);
                }
                return _objResponse;
            }
        }
}
